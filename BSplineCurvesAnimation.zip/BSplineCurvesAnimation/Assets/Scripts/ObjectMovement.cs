﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMovement : MonoBehaviour
{
    
    public float speed = 0.05f;
    private bool coroutineAllowed;
    private float t = 0f;
    public int numberOfControlPoints;
    public Transform[] controlPoints;
    

    private void Start()
    {
        coroutineAllowed = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (coroutineAllowed) {
            StartCoroutine(GoOnCurve());
        }
        
    }

    private IEnumerator GoOnCurve()
    {
        coroutineAllowed = false;
        Vector3 tangent = new Vector3(0, 0, 0);

        for (int i = 1; i < numberOfControlPoints - 2; i++)
        {
            while (t < 1)
            {
                t += Time.deltaTime * speed;

                transform.position = ((-Mathf.Pow(t, 3) + 3 * Mathf.Pow(t, 2) - 3 * t + 1) * controlPoints[i - 1].position
                    + (3 * Mathf.Pow(t, 3) - 6 * Mathf.Pow(t, 2) + 4) * controlPoints[i].position
                    + (-3 * Mathf.Pow(t, 3) + 3 * Mathf.Pow(t, 2) + 3 * t + 1) * controlPoints[i + 1].position
                    + Mathf.Pow(t, 3) * controlPoints[i + 2].position) / (float)6;
                Debug.Log(transform.position);
                tangent = (controlPoints[i-1].position * (-3*Mathf.Pow(t,2) + 6 * t - 3) + 
                           controlPoints[i].position * (9*Mathf.Pow(t,2) - 12 * t) +
                           controlPoints[i+1].position * (-9*Mathf.Pow(t,2) + 6 * t + 3) +
                           controlPoints[i+2].position * 3*Mathf.Pow(t,2));

                /*Vector3 viewVector = tangent - transform.position;

                float dot = Vector3.Dot(viewVector.normalized, tangent.normalized);


                float angle = Mathf.Acos(dot)*Mathf.Rad2Deg;*/


                

                /*Vector3 rotationVector = new Vector3(-tangent.y, tangent.x,0);
                float angle = Mathf.Acos(Vector3.Dot(transform.position, tangent)/(transform.position.magnitude * tangent.magnitude)) * Mathf.Rad2Deg;
                
                //transform.rotation = Quaternion.Euler(0, angle, 0);
                transform.Rotate(rotationVector, angle);*/
                transform.LookAt(tangent);
                yield return new WaitForEndOfFrame();

            }

            t = 0f;
        }

        

        coroutineAllowed = true;
    }
}
