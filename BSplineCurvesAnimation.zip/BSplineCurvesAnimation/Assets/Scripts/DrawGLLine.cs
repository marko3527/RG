﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DrawGLLine : MonoBehaviour
{

    public Material lineMat;
    public Transform[] controlPoints;

    public List<Vector3> splinePoints;
    public List<Vector3> tangentPoints;

    private int numberOfPoints;
    public int numberOfControlPoints;

    // Start is called before the first frame update
    void Start()
    {
        numberOfPoints = 100;
        splinePoints = new List<Vector3>();
        tangentPoints = new List<Vector3>();
    }

    // Update is called once per frame
    void Update()
    {
        splinePoints = new List<Vector3>();
        tangentPoints = new List<Vector3>();
        for (int i = 1; i < numberOfControlPoints - 2; i++)
        {
            populateSplinePoints(controlPoints[i - 1].position, controlPoints[i].position,
                        controlPoints[i + 1].position, controlPoints[i + 2].position);
        }

    }


    private void populateSplinePoints(Vector3 point0, Vector3 point1, Vector3 point2, Vector3 point3)
    {
        float t = 0f;
        Vector3 B = new Vector3(0, 0, 0);
        Vector3 tangent = new Vector3(0, 0, 0);


        for (int i = 0; i < numberOfPoints; i++)
        {
            B = ((-Mathf.Pow(t, 3) + 3 * Mathf.Pow(t, 2) - 3 * t + 1) * point0
                + (3 * Mathf.Pow(t, 3) - 6 * Mathf.Pow(t, 2) + 4) * point1
                + (-3 * Mathf.Pow(t, 3) + 3 * Mathf.Pow(t, 2) + 3 * t + 1) * point2
                + Mathf.Pow(t, 3) * point3) / (float)6;
            splinePoints.Add(B);


          
            if (i % 25 == 0) {
                tangent = (point0 * (-3 * Mathf.Pow(t, 2) + 6 * t - 3) +
                       point1 * (9 * Mathf.Pow(t, 2) - 12 * t) +
                       point2 * (-9 * Mathf.Pow(t, 2) + 6 * t + 3) +
                       point3 * 3 * Mathf.Pow(t, 2));

                tangentPoints.Add(B);
                tangentPoints.Add(tangent);
            } 

            t += (1 / (float)numberOfPoints);
        }
    }

     void OnPostRender()
    {

        lineMat.SetPass(0);

        for (int i = 1; i < splinePoints.Count; i++) {
            GL.Begin(GL.LINES);
            GL.Color(Color.red);
            Vector3 firstPoint = splinePoints[i - 1];
            Vector3 secondPoint = splinePoints[i];
            GL.Vertex3(firstPoint.x, firstPoint.y, firstPoint.z);
            GL.Vertex3(secondPoint.x, secondPoint.y, secondPoint.z);
            GL.End();
        }
        

        for (int i = 0; i < tangentPoints.Count - 1; i++) {
            GL.Begin(GL.LINES);
            lineMat.SetPass(0);
            Vector3 curvePoint = tangentPoints[i];
            Vector3 tangentPoint = tangentPoints[i + 1];

            tangentPoint = 0.5f * (tangentPoint - curvePoint).normalized + curvePoint;

            GL.Vertex3(tangentPoint.x, tangentPoint.y, tangentPoint.z);
            GL.Vertex3(curvePoint.x, curvePoint.y, curvePoint.z);
            
            GL.End();
        }
        
    }
}
