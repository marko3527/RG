﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController characterController;
    public Animator animator;
    public float gravity = -9.81f;
    public float jumpHeight = 1f;
    public float speed = 12f;

    Vector3 velocity;

    private bool groundedPlayer;


    // Update is called once per frame
    void Update()
    {

        groundedPlayer = characterController.isGrounded;

        if (groundedPlayer && velocity.y < 0) {
            velocity.y = -2f;
            if (animator.GetBool("Jump"))
            {
                animator.SetBool("Jump", false);
            }
        }

        Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        characterController.Move(move * Time.deltaTime * speed);

        if (move != Vector3.zero)
        {
            animator.SetBool("Moving", true);
            gameObject.transform.forward = move;
        }
        else {
            animator.SetBool("Moving", false);
        }


        if (Input.GetButtonDown("Jump") && groundedPlayer)
        {
            velocity.y += Mathf.Sqrt(jumpHeight * -2f * gravity);
            animator.SetBool("Jump", true);
        }

        velocity.y += gravity * Time.deltaTime;
        characterController.Move(velocity * Time.deltaTime);

        

        
        

    }
}
