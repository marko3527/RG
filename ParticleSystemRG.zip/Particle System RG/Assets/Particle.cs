﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Particle : MonoBehaviour
{

    GameObject particle;
    Transform particleTransform;
    
    float velocity;
    float timeToLive;
    float timeLived;
    Vector3 direction;
    Renderer renderer;

    public Particle(GameObject particlePrefab, float minTimeToLive, float maxTimeToLive,
                    Vector3 startingPosition, float minRangeForDirection,
                    float maxRangeForDirection, float minVelocity, float maxVelocity)
    {
        this.velocity = Random.Range(minVelocity, maxVelocity);

        particle = Instantiate(particlePrefab,
                               startingPosition,
                               Quaternion.identity);
        timeLived = 0;
        renderer = particle.GetComponent<Renderer>();
        renderer.material.color = Color.Lerp(Color.black, Color.white, timeLived / 2);
        direction = new Vector3(Random.Range(minRangeForDirection, maxRangeForDirection),
                                Random.Range(minRangeForDirection, maxRangeForDirection),
                                Random.Range(minRangeForDirection, maxRangeForDirection));
        particleTransform = particle.transform;
        particleTransform.LookAt(direction);
        timeToLive = Random.Range(minTimeToLive, maxTimeToLive);
    }


    public bool refresh(float deltaTime) {
        Renderer renderer = particle.GetComponent<Renderer>();
        timeLived += deltaTime;
        if (timeLived > timeToLive) {
            Destroy(particle);
            return true;
        }
        particleTransform.Translate(0.0f, velocity * Time.deltaTime, 0.0f);
        renderer.material.color = Color.Lerp(Color.black, Color.gray, timeLived/3);
        Vector3 targetScale = new Vector3(0.1f, 0.1f, 0.1f);
        particleTransform.localScale = Vector3.Lerp(particleTransform.localScale,
                                        new Vector3(0.7f,0.7f,0.7f), timeLived / timeToLive);
        return false;
    }
}
