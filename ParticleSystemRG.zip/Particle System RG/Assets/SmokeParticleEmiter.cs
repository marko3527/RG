﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmokeParticleEmiter : MonoBehaviour
{

    public float minVelocity = 1f;
    public float maxVelocity = 3f;

    public int numberOfParticlesAtStart = 200;

    public int minNumberOfParticles = 10;
    public int maxNumberOfParticles = 200;

    public bool shouldUseRandomVectorForInstantiating = true;
    public float maxRangeForPosition = -1f;
    public float minRangeForPosition = 1f;
    public Vector3 startingPosition;

    public float minTimeToLive = 0.1f;
    public float maxTimeToLive = 3f;

    public float minRangeForDirection = -1f;
    public float maxRangeForDirection = 1f;

    int numberOfParticles;
    List<Particle> particles;
    public GameObject particlePrefab;
    // Start is called before the first frame update
    void Start()
    {

        if (shouldUseRandomVectorForInstantiating)
        {
            startingPosition = new Vector3(Random.Range(minRangeForPosition, maxRangeForPosition),
                                           Random.Range(minRangeForPosition, maxRangeForPosition),
                                           Random.Range(minRangeForPosition, maxRangeForPosition));
        }
        
        particles = new List<Particle>();
        for (int i = 0; i < numberOfParticlesAtStart; i++) {
            particles.Add(new Particle(particlePrefab, minTimeToLive, maxTimeToLive, startingPosition, minRangeForDirection, maxRangeForDirection, minVelocity, maxVelocity));
        }
        Invoke("ChangeParticleNumber", 0.5f);

    }

    // Update is called once per frame
    void Update()
    {
        for (int i = 0; i < particles.Capacity; i++)
        {
           
            if (particles[i].refresh(Time.deltaTime))
            {
                particles.RemoveAt(i);
            }
            
        }

    }

    private void ChangeParticleNumber() {
        float randomTime = 0.5f;
        
        numberOfParticles = Random.Range(minNumberOfParticles, maxNumberOfParticles);
        Debug.Log(numberOfParticles);
        for (int i = 0; i < numberOfParticles; i++)
        {
            particles.Add(new Particle(particlePrefab, minTimeToLive, maxTimeToLive, startingPosition, minRangeForDirection, maxRangeForDirection, minVelocity, maxVelocity));
        }

        Invoke("ChangeParticleNumber", randomTime);
    }

}
